import React, {useCallback, useState} from 'react'

export default function TextForm(props) {
  const handleUpClick = () =>{
    let newText = text.toUpperCase();
    setText(newText)
  }
  const handleLwClick = () =>{
    let newText = text.toLowerCase();
    setText(newText)
  }
  const handleOnChange = (event) =>{
    setText(event.target.value);
  }
  const handleClrClick = (event) =>{
    setText('');
  }
  const handleRevClick = (event)=>{
    let newText = text.split('').reverse().join('');
    setText(newText);
  }

  const handleCapCaseClick = (event)=>{
    let newText = text.toLowerCase().split(' ').map(text =>{
      return text.charAt(0).toUpperCase()+text.slice(1)
    }).join(' ');
    setText(newText);
  }
  const handleSentCaseClick = (event)=>{
    let newText = text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
    setText(newText);
  }
  const handleInvCaseClick = (event)=>{
    let newText = text => [...text].map(char => char === char.toUpperCase() ? char.toLowerCase() : char.toUpperCase()).join('');    
    setText(newText);
  }

  const handleFileDownload = (event)=>{
    const textDataBlob = new Blob([text],{type: "text/plain"});
    const downloadUrl = window.URL.createObjectURL(textDataBlob)
     const downloadlink = document.createElement('a');
     downloadlink.download = "SampleText";
     downloadlink.href = downloadUrl;
     downloadlink.click();
  }
  
  const[text, setText] = useState('Enter text here');
  return (
    <>
      <div className='container'>
          <h1>{props.heading}</h1>
          <div className="mb-3">
              <textarea className="form-control" value={text} onChange={handleOnChange} id="myBox" rows="8"></textarea>
          </div>
          <button className="btn btn-primary mx-3" onClick={handleUpClick}>Convert to uppercase</button>
          <button className="btn btn-secondary mx-3" onClick={handleLwClick}>Convert to lowercase</button>
          <button className="btn btn-outline-success mx-3" onClick={handleRevClick}>Convert to Reverce</button>
          <button className="btn btn-warning mx-3 " onClick={handleClrClick}>Clear text</button>
          <button className="btn btn-danger mx-3 " onClick={handleCapCaseClick}>Convert to Capitalized</button>
          <button className="btn btn-success mx-3 " onClick={handleSentCaseClick}>Convert to Sentence case</button>
          <button className="btn btn-info mx-3 my-3" onClick={handleInvCaseClick}>Convert to Inverse case</button>
          <button className="btn btn-dark mx-3 my-3" onClick={handleFileDownload}><i className='bi bi-download'></i> Download Text file</button>
      </div>
      <div className='container my-3'>
        <h2>Your text summery</h2>
        <p>{text.split(" ").length} words and {text.length} characters</p>
        <p>Time to read text : {0.0008 * text.split(" ").length} seconds</p>
        <p>Priview : {text}</p>
        <p>No. of Lines : {text.split(/\r*\n/).length}</p>
        </div>
    </>
  )
}
